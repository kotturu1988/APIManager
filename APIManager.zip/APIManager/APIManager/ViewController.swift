//
//  ViewController.swift
//  APIManager
//
//  Created by AK-Mac on 6/25/20.
//  Copyright © 2020 AKSolutions. All rights reserved.
//

import UIKit
 

class ViewController: UIViewController {
    
    let api = APIManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }


}

