//
//  APIManager.swift
//  APIManager
//
//  Created by AK-Mac on 6/25/20.
//  Copyright © 2020 AKSolutions. All rights reserved.
//

import Foundation

class APIManager {
    
    var httpRequestHeaders = APIEntity()
    var httpBodyParams = APIEntity()
    var urlParams = APIEntity()
    var httpBody : Data?
    static var failedRequestPool = [APIManager?]()
    var url : URL?
    var httpMethod  : HttpMethod?
    var completionResults :  ((APIManager.Results) -> Void)?
    
    var isAuthorised = false
    
    static func callFailedRequest(){
        
        if failedRequestPool.isEmpty {
            return
        }
        
        DispatchQueue.global().async {
            guard let api = APIManager.failedRequestPool.first else{return}
            api?.makeRequest(url: (api?.url)!, httpMethod: (api?.httpMethod)!, isFromPool: true, completion: (api?.completionResults)!)
        }
    }
    
    private func addURlParams(url :URL)->URL{
        
        if urlParams.totalValues() > 0{
            guard var urlComponents = URLComponents(url: url, resolvingAgainstBaseURL: false) else{ return url}
        
            var queryItems = [URLQueryItem]()
            for (key,value) in urlParams.allValues(){
                let item = URLQueryItem(name: key, value: value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed))
                queryItems.append(item)
            }
            
            urlComponents.queryItems = queryItems
            
            guard let updatedUrl = urlComponents.url else {return url}
            return updatedUrl

        }
        return url
    }
    
    private func getHttpBody() -> Data?{
        guard let contentType = httpRequestHeaders.value(forKey: "Content-Type") else {return nil}
        
        if contentType.contains("application/json"){
            return try? JSONSerialization.data(withJSONObject: httpBodyParams.allValues(), options: [.prettyPrinted, .sortedKeys])
        } else if contentType.contains("application/x-www-form-urlencoded"){
            let bodyString = httpBodyParams.allValues().map { "\($0)=\(String(describing: $1.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)))" }.joined(separator: "&")
            return bodyString.data(using: .utf8)
        }
        
        return httpBody
    }
    
    private func prepareURLRequest(url:URL?,httpBody:Data?,httpMethod: HttpMethod) -> URLRequest?{
        
        guard let url = url else {return nil}
        var request = URLRequest(url: url)
        request.httpMethod = httpMethod.rawValue
        
        for (header,value) in httpRequestHeaders.allValues(){
            request.setValue(value, forHTTPHeaderField: header)
        }
        request.httpBody = httpBody
        return request
        
    }
   
    func makeRequest(url:URL, httpMethod : HttpMethod, isFromPool : Bool, completion: @escaping(_ result : Results) -> Void) {
        
            DispatchQueue.global(qos: .userInitiated).async {
                [weak self] in
                
                let targetURL = self?.addURlParams(url: url)
                let httpBody = self?.getHttpBody()
                
                guard let request = self?.prepareURLRequest(url: targetURL, httpBody: httpBody, httpMethod: httpMethod) else{
                    completion(Results(error: CustomError.createRequestError))
                    return
                }
                
                let sessionConfig = URLSessionConfiguration.default
                let session = URLSession(configuration: sessionConfig)
                let task = session.dataTask(with: request){ (data, response, error) in
                    if error != nil{
                        self?.url = url
                        self?.completionResults = completion
                        self?.httpMethod = httpMethod
                        if !isFromPool {
                            APIManager.failedRequestPool.append(self)
                        }
                    }else{
                        self?.isAuthorised = true
                        if isFromPool{
                            APIManager.failedRequestPool.removeFirst()
                        }
                        APIManager.callFailedRequest()
                    }
                    completion(Results(data: data, response: Response(fromResponse: response), error: error))
                }
                task.resume()
            }
        
    }
    
    func getData(url:URL, completion: @escaping (_ data : Data?)-> Void){
        DispatchQueue.global(qos: .userInitiated).async {
            let sessionConfiguration = URLSessionConfiguration.default
            let session = URLSession(configuration: sessionConfiguration)
            let task = session.dataTask(with: url, completionHandler: { (data, response, error) in
                guard let data = data else { completion(nil); return }
                completion(data)
            })
            task.resume()
        }
    }

    
}
extension APIManager {
    
    enum HttpMethod : String{
        case get
        case post
        case put
        case patch
        case delete
    }
    
    struct APIEntity {
        private var values : [String:String] = [:]
        
        mutating func add(value:String, forKey key:String){
            values[key] = value
        }
        
        func value(forKey key:String) -> String?{
            return values[key]
        }
        func allValues() -> [String:String]{
            return values
        }
        func  totalValues() -> Int {
            return values.count
        }
    }
    // Defining Response Struct
    struct Response {
        var response : URLResponse?
        var statusCode : Int = 0
        var headers = APIEntity()
        
        init(fromResponse response : URLResponse?) {
            guard let response = response else { return }
            self.response = response
            statusCode = (response as? HTTPURLResponse)?.statusCode ?? 0
            
            if let headerFields = (response as? HTTPURLResponse)?.allHeaderFields{
                for (key,value) in headerFields{
                    headers.add(value: "\(value)", forKey: "\(key)")
                }
            }
            
        }
    }
    // Defining results struct
    struct Results {
        var data : Data?
        var response : Response?
        var error : Error?
        
        init(data: Data?, response : Response?, error : Error?) {
            self.data = data
            self.response = response
            self.error = error
        }
        init(error: Error) {
            self.error = error
        }
    }
    
    enum CustomError : Error{
        case createRequestError
    }
    
}

extension APIManager.CustomError : LocalizedError{
    public var localizedDescription: String{
        switch self {
        case .createRequestError : return NSLocalizedString("Unable to create the request object ", comment: "")
        }
    }
}
